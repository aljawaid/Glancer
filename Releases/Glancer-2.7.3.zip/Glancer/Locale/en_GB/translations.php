<?php

// Related regression test: tests/UiRegressionTest.php.

return array(
    //
    // GENERAL
    //
    'Quickly jump to a project, task or comment through a bar at the bottom of the screen. Use the new copy to clipboard feature in different formats coupled with the new global shortcut icon to realise why Glancer was built for power users. Following the \'Getting Things Done\' methodology, productive users can glance through their workflow easily.' => 'Quickly jump to a project, task or comment through a bar at the bottom of the screen. Use the new copy to clipboard feature in different formats coupled with the new global shortcut icon to realise why Glancer was built for power users. Following the \'Getting Things Done\' methodology, productive users can glance through their workflow easily.',
    //
    // config/settings.php
    //
    'Settings' => 'Settings',
    'Global Shortcut Options' => 'Global Shortcut Options',
    'The Glancer bar can show a shortcut to a website which you may regularly need access to whilst using this application. The icon will only show if a website address is set below.' => 'The Glancer bar can show a shortcut to a website which you may regularly need access to whilst using this application. The icon will only show if a website address is set below.',
    'Reference Label' => 'Reference Label',
    'This label is not used on the icon' => 'This label is not used on the icon',
    'Tooltip Title' => 'Tooltip Title',
    'This text displays in the tooltip' => 'This text displays in the tooltip',
    'Website URL' => 'Website URL',
    'Enter a complete HTTP or HTTPS website URL' => 'Enter a complete HTTP or HTTPS website URL',
    'The shortcut is hidden until a valid HTTP or HTTPS URL is saved.' => 'The shortcut is hidden until a valid HTTP or HTTPS URL is saved.',
    'Privacy' => 'Privacy',
    'Shortcut links always protect the Kanboard page and suppress referral details.' => 'Shortcut links always protect the Kanboard page and suppress referral details.',
    'Glancer always adds `rel="noopener noreferrer"` to shortcut links. This privacy protection cannot be disabled.' => 'Glancer always adds `rel="noopener noreferrer"` to shortcut links. This privacy protection cannot be disabled.',
    'Link Opening' => 'Link Opening',
    'Open the link in a new window' => 'Open the link in a new window',
    'Open the link in the same window' => 'Open the link in the same window',
    'Opening the website in the same window may affect your browser session.' => 'Opening the website in the same window may affect your browser session.',
    'Default Icon' => 'Default Icon',
    'Shortcut Icon' => 'Shortcut Icon',
    'Opens in a new window' => 'Opens in a new window',
    'View Collection' => 'View Collection',
    'View Cheatsheet' => 'View Cheatsheet',
    'Use default icon' => 'Use default icon',
    'Use other icon' => 'Use other icon',
    'Other' => 'Other',
    'The default icon is suitable for documentation-type websites as the icon itself is a book. To choose your own icon, select the \'Other icon\' options and enter the icon code from the FontAwesome website.' => 'The default icon is suitable for documentation-type websites as the icon itself is a book. To choose your own icon, select the \'Other icon\' options and enter the icon code from the FontAwesome website.',
    'Enter the icon class name.' => 'Enter the icon class name.',
    'Use one Font Awesome class such as fa-newspaper-o. The default icon is shown for invalid values.' => 'Use one Font Awesome class such as fa-newspaper-o. The default icon is shown for invalid values.',
    'CSS Styling' => 'CSS Styling',
    'The icon uses the following classes for styling. You can further customise the icon through your custom stylesheet.' => 'The icon uses the following classes for styling. You can further customise the icon through your custom stylesheet.',
    'Targets the link' => 'Targets the link',
    'Targets the default icon' => 'Targets the default icon',
    'Targets the FontAwesome icon' => 'Targets the FontAwesome icon',
    'Saves any changes made on this page' => 'Saves any changes made on this page',
    'Save Settings' => 'Save Settings',
    //
    // layout/glancer.php
    //
    'View Dashboard (Tasks)' => 'View Dashboard (Tasks)',
    'Open shortcut' => 'Open shortcut',
    'Task ID' => 'Task ID',
    'Enter Task ID' => 'Enter Task ID',
    'Search' => 'Search',
    'Comment ID' => 'Comment ID',
    'Enter Comment ID' => 'Enter Comment ID',
    'Project ID' => 'Project ID',
    'Enter Project ID' => 'Enter Project ID',
    //
    // task/desciption.php
    //
    'Description' => 'Description',
    'Complete' => 'Complete',
    'Not complete' => 'Not complete',
    'No description' => 'No description',
    'Copy HTML version' => 'Copy HTML version',
    'Copy to Clipboard' => 'Copy to Clipboard',
    'Copy markdown version' => 'Copy markdown version',
    'Copy formatted version' => 'Copy formatted version',
    'Copy No line breaks version' => 'Copy No line breaks version',
    'Copied' => 'Copied',
    'Not copied' => 'Not copied',
    //
    // project_overview/activity.php
    //
    'Last activity' => 'Recent activity',
    //
    // event/events.php
    //
    'There is no activity yet.' => 'There is no activity yet.',
    //
    // comment/show.php comment/show-latest.php
    //
    'Activity' => 'Activity',
    'Switch between relative and exact dates' => 'Switch between relative and exact dates',
    'Date Created' => 'Date Created',
    'Local Time' => 'Local Time',
    'LT' => 'LT',
    'Date Updated' => 'Date Updated',
    'Updated' => 'Updated',
    'Comment ID' => 'Comment ID',
    'ID ' => 'ID ',
    'Go to the top of the page' => 'Go to the top of the page',
    'Top' => 'Top',
    'Board' => 'Board',
    'View the project board' => 'View the project board',
    'Overview' => 'Overview',
    'View recent activity in this project' => 'View recent activity in this project',
    'Link' => 'Link',
    'Reply' => 'Reply',
    'Edit' => 'Edit',
    'Remove' => 'Delete',
    'Visibility:' => 'Visibility:',
    'Standard users' => 'Standard users',
    'Application managers or more' => 'Application managers or more',
    'Administrators' => 'Administrators',
    //
    // event/comment_create.php event/comment_create-latest.php
    //
    '%s commented on %s' => '%s commented on %s',
    '#%d' => '#%d',
    'View Task' => 'View Task',
    'Created' => 'Created',
    'Task Title' => 'Task Title',
    'View Comment' => 'View Comment',
    //
    // event/comment_update.php event/comment_update-latest.php
    'Showing Updated Content' => 'Showing Updated Content',
    'Updated Comment' => 'Updated Comment',
    'Originally Created' => 'Originally Created',
    'Comment Last Updated' => 'Comment Last Updated',
    '%s updated a comment on task %s' => '%s updated a comment on task %s',
    //
    // event/comment_delete.php event/comment_delete-latest.php
    //
    'Showing Deleted Content' => 'Showing Deleted Content',
    'Deleted Comment' => 'Deleted Comment',
    '%s removed a comment on task %s' => '%s removed a comment on task %s',
    'This Comment ID cannot be searched' => 'This Comment ID cannot be searched',
    //
    // TaskCommentViewController.php
    //
    '&#10008; Unable to find comment #%s. Directed to dashboard.' => '&#10008; Unable to find comment #%s. Directed to dashboard.',
    '&#10008; Unable to find a comment without an ID. Directed to dashboard.' => '&#10008; Unable to find a comment without an ID. Directed to dashboard.',
    '&#10008; Unable to find project #%s. Directed to dashboard.' => '&#10008; Unable to find project #%s. Directed to dashboard.',
    '&#10008; Unable to find a project without an ID. Directed to dashboard.' => '&#10008; Unable to find a project without an ID. Directed to dashboard.',
    '&#10008; Unable to find task #%s. Directed to dashboard.' => '&#10008; Unable to find task #%s. Directed to dashboard.',
    '&#10008; Unable to find a task without an ID. Directed to dashboard.' => '&#10008; Unable to find a task without an ID. Directed to dashboard.',
    //
    // task/navigation.php
    //
    'Previous Task' => 'Previous Task',
    'Navigate through all open tasks in this project' => 'Navigate through all open tasks in this project',
    'Next Task' => 'Next Task',
    //
    // AgeHelper.php
    //
    'less than a minute ago' => 'less than a minute ago',
    'less than 5 minutes ago' => 'less than 5 minutes ago',
    'less than 10 minutes ago' => 'less than 10 minutes ago',
    'around 15 minutes ago' => 'around 15 minutes ago',
    'around half an hour ago' => 'around half an hour ago',
    'around 45 minutes ago' => 'around 45 minutes ago',
    'around an hour ago' => 'around an hour ago',
    'around 2 hours ago' => 'around 2 hours ago',
    'around 3 hours ago' => 'around 3 hours ago',
    'around 4 hours ago' => 'around 4 hours ago',
    'around 5 hours ago' => 'around 5 hours ago',
    'around 6 hours ago' => 'around 6 hours ago',
    'around 12 hours ago' => 'around 12 hours ago',
    'earlier today' => 'earlier today',
    'yesterday' => 'yesterday',
    'a few days ago' => 'a few days ago',
    'less than a week ago' => 'less than a week ago',
    'about a week ago' => 'about a week ago',
    'over a week ago' => 'over a week ago',
    'about 10 days ago' => 'about 10 days ago',
    'about 2 weeks ago' => 'about 2 weeks ago',
    'just over 2 weeks ago' => 'just over 2 weeks ago',
    'nearly 3 weeks ago' => 'nearly 3 weeks ago',
    'about 3 weeks ago' => 'about 3 weeks ago',
    'over 3 weeks ago' => 'over 3 weeks ago',
    'about a month ago' => 'about a month ago',
    'just over a month ago' => 'just over a month ago',
    'over a month ago' => 'over a month ago',
    'about 2 months ago' => 'about 2 months ago',
    'over 2 months ago' => 'over 2 months ago',
    'about 3 months ago' => 'about 3 months ago',
    'just over 3 months ago' => 'just over 3 months ago',
    'over 3 months ago' => 'over 3 months ago',
    'about 4 months ago' => 'about 4 months ago',
    'just over 4 months ago' => 'just over 4 months ago',
    'about 5 months ago' => 'about 5 months ago',
    'just over 5 months ago' => 'just over 5 months ago',
    'about 6 months ago' => 'about 6 months ago',
    'just over 6 months ago' => 'just over 6 months ago',
    'over 6 months ago' => 'over 6 months ago',
    'a year ago' => 'a year ago',
    'just over a year ago' => 'just over a year ago',
    'over a year ago' => 'over a year ago',
    'about 2 years ago' => 'about 2 years ago',
    'over 2 years ago' => 'over 2 years ago',
    'about 3 years ago' => 'about 3 years ago',
    'over 3 years ago' => 'over 3 years ago',
    'about 4 years ago' => 'about 4 years ago',
    'over 4 years ago' => 'over 4 years ago',
    'about 5 years ago' => 'about 5 years ago',
    'over 5 years ago' => 'over 5 years ago',
);
