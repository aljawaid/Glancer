# Changelog


## v1.5

### What's Changed

_(most recent changes are listed on top):_
- FIX: Untranslated Strings
- NEW: Show Relative Date with Exact Date in Tooltip - Toggles to exact date when clicked
- NEW: #17 Add Switchable Date in Time Ago
- FIX: #16 JS Blocks Anchor Links
- NEW: Add Project Overview Button in Comment Hover
- Fix #14 Bug: Normal Users Login Issue


## v1.0

### What's Changed

_(most recent changes are listed on top):_
- Initial release
- Added `en_GB` translations


[**Full Changelog**](../master/changelog.md "See changes")

[**README**](../master/README.md "View README")
