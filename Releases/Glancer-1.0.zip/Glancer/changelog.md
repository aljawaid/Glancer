# Changelog


## v1.0

### What's Changed

_(most recent changes are listed on top):_
- Initial release
- Added `en_GB` translations


[**Full Changelog**](../master/changelog.md "See changes")

[**README**](../master/README.md "View README")
